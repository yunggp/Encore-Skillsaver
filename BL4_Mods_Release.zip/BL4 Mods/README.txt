BL4 Mods - Encore Teleport + Skill Saver
Version date: 2026-10-07
  Encore Teleport  mod v3.27
  Skill Saver      mod v2.2
  Desktop app      v5.12


WHAT IS INSIDE
  sdk_mods/EncoreTeleport.sdkmod        the Encore Teleport mod
  sdk_mods/SkillSaver.sdkmod            the Skill Saver mod
  sdk_mods/EncoreTeleport_stations.json list of Encore machines that are already found
  Encore Teleport App/                  the desktop app (Windows)


INSTALL
1. Copy EncoreTeleport.sdkmod and SkillSaver.sdkmod into the sdk_mods folder
   of the game (replace old files). Usual path: ...\Borderlands 4\sdk_mods

2. EncoreTeleport_stations.json is a start list with all Encore machines found
   so far. Copy it into sdk_mods too - but NOT if you already have your own
   list, because it would replace it.

3. Put the "Encore Teleport App" folder anywhere and start
   "Start EncoreTeleport.bat". If the app can not find the sdk_mods folder on
   the first start, it asks you for it.

4. Start the game. The app connects by itself.


HOW TO USE
Bosses page
  - All saved Encore machines, sorted by map. Double click = teleport.
    On another map the mod fast travels there first.
  - Favorite: puts a boss in the FAVORITES list at the top. Places 1-5 can be
    used in game with keys (default F5-F9). Change the keys with "Keys...".
    Change the order with the arrow buttons.
  - Nearest / Back / Rename / Remove are in the app as well.
  - New machines are saved by the mod automatically when you come near them.

Skills page (Ctrl+Tab)
  - Save new / Load / Overwrite / Rename / Delete your full skill setup:
    skill points, action skill, augment, capstone, specialization skills.
  - Undo load: go back to the setup you had before the last load.
  - Reset tree: get all skill points back, anywhere.
  - For every build you see: action skill, augment, capstone, specialization,
    your gear (name, element for weapons and ordnance), firmware sets, a gear
    check (worn / in backpack / not found) and your own notes ("Gear...").
  - Gear is only shown as text. It is not equipped by the mod.


OPTIONAL: REAL ITEM NAMES
Install Matt's SDK Boosting Tools (MattsSDKBoostingTools.sdkmod) in sdk_mods:
  https://github.com/funkyoushift/MattsSDKBoostingTools
With it, Skill Saver shows the real item names (for example "Tempered Essence")
and the firmware of every item. Without it you only see a description like
"Legendary Vladof SMG".


REQUIREMENTS
  - oak2 SDK / oak2-mod-manager (mods_base.sdkmod, console_mod_menu.sdkmod)
  - Single player or host only


CREDITS
Thanks to Matt (FunkYouSHiFT) for Matt's SDK Boosting Tools - the way Skill
Saver reads item serials is based on his work.
